/**
 * Support classes for serving static resources.
 */
package org.springframework.web.servlet.resource;
