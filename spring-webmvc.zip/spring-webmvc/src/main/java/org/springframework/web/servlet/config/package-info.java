/**
 * Defines the XML configuration namespace for Spring MVC.
 */
package org.springframework.web.servlet.config;
