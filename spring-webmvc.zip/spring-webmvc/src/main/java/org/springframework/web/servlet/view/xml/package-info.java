/**
 * Support classes for providing a View implementation based on XML Marshalling.
 */
package org.springframework.web.servlet.view.xml;
