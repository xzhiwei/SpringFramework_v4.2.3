/**
 * Provides generic filter base classes allowing for bean-style configuration.
 */
package org.springframework.web.filter;
