/**
 * ELResolvers for integrating a JSF web layer with a Spring service layer
 * which is hosted in a Spring root WebApplicationContext.
 */
package org.springframework.web.jsf.el;
