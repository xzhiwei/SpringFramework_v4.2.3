/**
 * Support for CORS (Cross-Origin Resource Sharing),
 * based on a common {@code CorsProcessor} strategy.
 */
package org.springframework.web.cors;
