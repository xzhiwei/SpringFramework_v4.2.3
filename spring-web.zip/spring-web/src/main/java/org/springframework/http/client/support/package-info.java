/**
 * This package provides generic HTTP support classes,
 * to be used by higher-level classes like RestTemplate.
 */
package org.springframework.http.client.support;
