/**
 * Provides an HttpMessageConverter implementations for handling XML.
 */
package org.springframework.http.converter.xml;
