/**
 * Provides an HttpMessageConverter abstraction to convert between Java objects and HTTP input/output messages.
 */
package org.springframework.http.converter;
