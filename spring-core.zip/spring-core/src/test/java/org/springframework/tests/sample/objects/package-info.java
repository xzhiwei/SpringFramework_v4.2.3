/**
 * General purpose sample objects that can be used with tests.
 */
package org.springframework.tests.sample.objects;
