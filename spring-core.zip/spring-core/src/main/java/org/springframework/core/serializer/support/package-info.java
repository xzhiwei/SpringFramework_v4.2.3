/**
 * Support classes for Spring's serializer abstraction.
 * Includes adapters to the Converter SPI.
 */
package org.springframework.core.serializer.support;
