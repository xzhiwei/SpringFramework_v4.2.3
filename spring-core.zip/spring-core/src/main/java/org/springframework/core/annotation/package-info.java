/**
 * Core support package for annotations, meta-annotations, and composed
 * annotations with attribute overrides.
 */
package org.springframework.core.annotation;
