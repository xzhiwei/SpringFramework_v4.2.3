/**
 * Type conversion system API.
 */
package org.springframework.core.convert;
