/**
 * Spring's environment abstraction consisting of bean definition
 * profile and hierarchical property source support.
 */
package org.springframework.core.env;
