/**
 * Useful generic {@code java.util.Comparator} implementations,
 * such as an invertible comparator and a compound comparator.
 */
package org.springframework.util.comparator;
